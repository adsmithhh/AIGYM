#!/usr/bin/env python3
import sys, re, json
try:
    import yaml
except ImportError:
    print("Requires PyYAML: pip install pyyaml", file=sys.stderr)
    sys.exit(1)

SHA_RE = re.compile(r"^sha256:[0-9a-fA-F]{6,}$")
TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

REQUIRED_ROOT = ["exchange_manifest"]
REQUIRED_BASE = ["arch_id","shapes_hash","tokenizer_id","tokenizer_hash","dtype_runtime"]
REQUIRED_PAYLOAD = ["type","id","target_layers","dtype","blob","license_id","safety_class"]

def fail(msg):
    print(f"[FAIL] {msg}")
    sys.exit(2)

def check_manifest(path):
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        fail("Root must be a map")
    if "exchange_manifest" not in data:
        fail("Missing root key: exchange_manifest")
    m = data["exchange_manifest"]
    if m.get("version") != "0.1":
        fail("exchange_manifest.version must be '0.1'")
    base = m.get("base_model", {})
    for k in REQUIRED_BASE:
        if k not in base:
            fail(f"Missing base_model.{k}")
    if not SHA_RE.match(base["shapes_hash"]):
        fail("base_model.shapes_hash invalid")
    if not SHA_RE.match(base["tokenizer_hash"]):
        fail("base_model.tokenizer_hash invalid")
    if base["dtype_runtime"] not in ("fp32","bf16","fp16","int8"):
        fail("base_model.dtype_runtime invalid")
    payloads = m.get("payloads", [])
    if not payloads:
        fail("No payloads provided")
    for i,p in enumerate(payloads):
        for k in REQUIRED_PAYLOAD:
            if k not in p:
                fail(f"payload[{i}].{k} missing")
        if p["type"] not in ("lora","ia3","full-diff"):
            fail(f"payload[{i}].type invalid")
        blob = p["blob"]
        if not SHA_RE.match(blob.get("sha256","")):
            fail(f"payload[{i}].blob.sha256 invalid")
    att = m.get("attestation", {})
    ts = att.get("timestamp_utc","")
    if not TS_RE.match(ts):
        fail("attestation.timestamp_utc invalid")
    print("[OK] Manifest basic checks passed.")
    return True

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: verify_manifest.py <manifest.yaml>")
        sys.exit(1)
    ok = check_manifest(sys.argv[1])
    sys.exit(0 if ok else 2)
