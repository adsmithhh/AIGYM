# Changelog

## v0.1 — 2025-08-10
- Initial release of AIGYM handshake spec and examples.
